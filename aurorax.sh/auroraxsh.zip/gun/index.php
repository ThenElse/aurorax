<!DOCTYPE html>
<html lang="tr">



<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<embed src="song.mp3" hidden="true" autostart="true" loop="true">
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Linux kullanıcıları için kolaylaştırılmış otomatik kurulum sistemleri sağlayan web sitemize hoş geldiniz.">
    <meta name="author" content="fb.com/elsethen">
    <meta name="keywords" content="linux kurulum scripti,linux scriptler,aurorax,muzik botu kurulum scripti,minecraft scripti,mta scripti,ubuntu uzakmasaüstü,teaspeak,teamspeak,npl,script,ts3,mta kur,csgo ubuntu,csgo linux,renkli ssh,linux,script,aurora script,proxy açma ts3,script şifreleme,script kırma,loglevel,youtubedll,date">
	<link rel="icon" href="favicon.ico" type="image/gif" sizes="16x16">

    <!-- Title Page-->
    <title>AuroraX Script - Anasayfa</title>

    <!-- Fontfaces CSS-->
	<base  /> 
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">
	<link rel="stylesheet" href="https://injectshell.com/css/bootstrap.css">

    <!-- Vendor CSS-->
    <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">
    <link href="vendor/vector-map/jqvmap.min.css" rel="stylesheet" media="all">
	  <script src="../cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert-dev.js"></script>
  <link rel="stylesheet" href="../cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css">

  
    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">
	<center><h1>Güncellemeler</h1></center>
	  <div align="center">
		<div id="google_translate_element"></div><script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'tr', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
}
</script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
	<br>
	<div class="alert">
  <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
  <strong>10.12.2018</strong> Scriptimiz Açıldı.
</div>


<style type="text/css">
/* The alert message box */
.alert {
    padding: 20px;
    background-color: #159890;
    color: white;
    margin-bottom: 15px;
}

/* The close button */
.closebtn {
    margin-left: 15px;
    color: white;
    font-weight: bold;
    float: right;
    font-size: 22px;
    line-height: 20px;
    cursor: pointer;
    transition: 0.3s;
}

/* When moving the mouse over the close button */
.closebtn:hover {
    color: black;
}
</style>