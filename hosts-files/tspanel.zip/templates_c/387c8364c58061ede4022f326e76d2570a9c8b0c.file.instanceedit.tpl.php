<?php /* Smarty version Smarty3rc4, created on 2018-02-05 02:59:13
         compiled from "C:\localhost\www\Ts3WebPanel\gelistir2\templates/mrstipfan/instanceedit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:69905a77c881276698-50430634%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '387c8364c58061ede4022f326e76d2570a9c8b0c' => 
    array (
      0 => 'C:\\localhost\\www\\Ts3WebPanel\\gelistir2\\templates/mrstipfan/instanceedit.tpl',
      1 => 1513634812,
    ),
  ),
  'nocache_hash' => '69905a77c881276698-50430634',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<script type="text/javascript">
	$(function () {
		$('#instanceedit_showonweblist input[type="checkbox"]').on('change', function(){
			$.post({
				url: $('#instanceedit_showonweblist').attr('action'),
				data: $('#instanceedit_showonweblist').serialize(),
			})
		});
	});	
</script>
<section class="content container-fluid">
	<div class="col-xs-12 col-xs-offset-0 col-sm-10 col-sm-offset-1 col-md-10 col-md-offset-1 col-lg-10 col-lg-offset-1 no-padding">
	<?php if ($_smarty_tpl->getVariable('hoststatus')->value===false&&$_smarty_tpl->getVariable('serverhost')->value===true){?>
		<div class="alert alert-warning"><?php echo $_smarty_tpl->getVariable('lang')->value['nohoster'];?>
</div>
	<?php }else{ ?>
	<?php if (!empty($_smarty_tpl->getVariable('error')->value)){?>
		<div class="alert alert-danger"><?php echo $_smarty_tpl->getVariable('error')->value;?>
</div>
	<?php }?>
	<?php if (!empty($_smarty_tpl->getVariable('noerror')->value)){?>
		<div class="alert alert-info"><?php echo $_smarty_tpl->getVariable('noerror')->value;?>
</div>
	<?php }?>
		<div class="box box-primary" data-name="instanceedit_main">
			<div class="box-header">
				<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['instanceedit'];?>
</h3>
				<div class="box-tools pull-right">
					<button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
				</div>
			</div>
			<form class="box-body" method="post" action="index.php?site=instanceedit">
				<div class="row">
					<div class="col-md-4">
						<div class="form-group">
							<label for="new_serverinstance_guest_serverquery_group"><?php echo $_smarty_tpl->getVariable('lang')->value['questsquerygroup'];?>
</label>
							<input type="text" class="form-control" id="new_serverinstance_guest_serverquery_group" name="newsettings[serverinstance_guest_serverquery_group]" value="<?php echo $_smarty_tpl->getVariable('instanceinfo')->value['serverinstance_guest_serverquery_group'];?>
" />
						</div>
						<div class="form-group">
							<label for="new_serverinstance_template_serveradmin_group"><?php echo $_smarty_tpl->getVariable('lang')->value['tempsadmingroup'];?>
</label>
							<input type="text" class="form-control" id="new_serverinstance_template_serveradmin_group" name="newsettings[serverinstance_template_serveradmin_group]" value="<?php echo $_smarty_tpl->getVariable('instanceinfo')->value['serverinstance_template_serveradmin_group'];?>
" />
						</div>
						<div class="form-group">
							<label for="new_serverinstance_template_channeladmin_group"><?php echo $_smarty_tpl->getVariable('lang')->value['tempcadmingroup'];?>
</label>
							<input type="text" class="form-control" id="new_serverinstance_template_channeladmin_group" name="newsettings[serverinstance_template_channeladmin_group]" value="<?php echo $_smarty_tpl->getVariable('instanceinfo')->value['serverinstance_template_channeladmin_group'];?>
" />
						</div>
						<div class="form-group">
							<label for="new_serverinstance_template_serverdefault_group"><?php echo $_smarty_tpl->getVariable('lang')->value['tempsdefgroup'];?>
</label>
							<input type="text" class="form-control" id="new_serverinstance_template_serverdefault_group" name="newsettings[serverinstance_template_serverdefault_group]" value="<?php echo $_smarty_tpl->getVariable('instanceinfo')->value['serverinstance_template_serverdefault_group'];?>
" />
						</div>
						<div class="form-group">
							<label for="new_serverinstance_template_channeldefault_group"><?php echo $_smarty_tpl->getVariable('lang')->value['tempcdefgroup'];?>
</label>
							<input type="text" class="form-control" id="new_serverinstance_template_channeldefault_group" name="newsettings[serverinstance_template_channeldefault_group]" value="<?php echo $_smarty_tpl->getVariable('instanceinfo')->value['serverinstance_template_channeldefault_group'];?>
" />
						</div>
					</div>
					<div class="col-md-4">
						<div class="form-group">
							<label for="new_serverinstance_filetransfer_port"><?php echo $_smarty_tpl->getVariable('lang')->value['filetransport'];?>
</label>
							<input type="text" class="form-control" id="new_serverinstance_filetransfer_port" name="newsettings[serverinstance_filetransfer_port]" value="<?php echo $_smarty_tpl->getVariable('instanceinfo')->value['serverinstance_filetransfer_port'];?>
" />
						</div>
						<div class="form-group">
							<label for="new_serverinstance_max_download_total_bandwidth"><?php echo $_smarty_tpl->getVariable('lang')->value['maxdownbandwidth'];?>
</label>
							<input type="text" class="form-control" id="new_serverinstance_max_download_total_bandwidth" name="newsettings[serverinstance_max_download_total_bandwidth]" value="<?php echo $_smarty_tpl->getVariable('instanceinfo')->value['serverinstance_max_download_total_bandwidth'];?>
" />
						</div>
						<div class="form-group">
							<label for="new_serverinstance_max_upload_total_bandwidth"><?php echo $_smarty_tpl->getVariable('lang')->value['maxupbandwidth'];?>
</label>
							<input type="text" class="form-control" id="new_serverinstance_max_upload_total_bandwidth" name="newsettings[serverinstance_max_upload_total_bandwidth]" value="<?php echo $_smarty_tpl->getVariable('instanceinfo')->value['serverinstance_max_upload_total_bandwidth'];?>
" />
						</div>
					</div>
					<div class="col-md-4">
						<div class="form-group">
							<label for="new_serverinstance_serverquery_flood_commands"><?php echo $_smarty_tpl->getVariable('lang')->value['squeryfloodcmd'];?>
</label>
							<input type="text" class="form-control" id="new_serverinstance_serverquery_flood_commands" name="newsettings[serverinstance_serverquery_flood_commands]" value="<?php echo $_smarty_tpl->getVariable('instanceinfo')->value['serverinstance_serverquery_flood_commands'];?>
" />
						</div>
						<div class="form-group">
							<label for="new_serverinstance_serverquery_flood_time"><?php echo $_smarty_tpl->getVariable('lang')->value['squeryfloodtime'];?>
</label>
							<input type="text" class="form-control" id="new_serverinstance_serverquery_flood_time" name="newsettings[serverinstance_serverquery_flood_time]" value="<?php echo $_smarty_tpl->getVariable('instanceinfo')->value['serverinstance_serverquery_flood_time'];?>
" />
						</div>
						<div class="form-group">
							<label for="new_serverinstance_serverquery_ban_time"><?php echo $_smarty_tpl->getVariable('lang')->value['squerybantime'];?>
</label>
							<input type="text" class="form-control" id="new_serverinstance_serverquery_ban_time" name="newsettings[serverinstance_serverquery_ban_time]" value="<?php echo $_smarty_tpl->getVariable('instanceinfo')->value['serverinstance_serverquery_ban_time'];?>
" />
						</div>
					</div>
				</div>
				<input class="btn btn-primary btn-flat btn-block" type="submit" name="editinstance" value="<?php echo $_smarty_tpl->getVariable('lang')->value['edit'];?>
" />
			</form>
		</div>
		<div class="box box-info" data-name="instanceedit_showonweblist">
			<div class="box-header">
				<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['showonweblist'];?>
</h3>
				<div class="box-tools pull-right">
					<button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
				</div>
			</div>
			<form class="box-body" id="instanceedit_showonweblist" method="post" action="index.php?site=instanceedit">
				<input type="hidden" name="editshowlist">
				<table class="table">
					<tr>
						<th class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['serverid'];?>
</th>
						<th><?php echo $_smarty_tpl->getVariable('lang')->value['name'];?>
</th>
						<th class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['status'];?>
</th>
						<th width="15%" class="text-right no-padding">
							<a href="javascript::void(0)" class="btn btn-flat btn-info btn-block" onclick="check(1)"><?php echo $_smarty_tpl->getVariable('lang')->value['selectall'];?>
</a>
						</th>
					</tr>
					<?php if (!empty($_smarty_tpl->getVariable('serverlist')->value)){?>
						<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('serverlist')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
							<tr>
								<td class="text-center"><?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_id'];?>
</td>
								<td style="vertical-align: middle;">
									<?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_name'];?>

								</td>
								<td class="text-center no-padding" style="vertical-align: middle;">
								<?php if ($_smarty_tpl->tpl_vars['value']->value['virtualserver_status']=="online"){?>
									<span class="btn btn-flat btn-xs btn-success disabled"><?php echo $_smarty_tpl->getVariable('lang')->value['online'];?>
</span>
								<?php }elseif($_smarty_tpl->tpl_vars['value']->value['virtualserver_status']=="online virtual"){?>
									<span class="btn btn-flat btn-xs btn-primary disabled"><?php echo $_smarty_tpl->getVariable('lang')->value['onlinevirtual'];?>
</span>
								<?php }elseif($_smarty_tpl->tpl_vars['value']->value['virtualserver_status']=="offline"){?>
									<span class="btn btn-flat btn-xs btn-danger disabled"><?php echo $_smarty_tpl->getVariable('lang')->value['offline'];?>
</span>
								<?php }?>
								</td>
								<td class="text-center no-padding" style="vertical-align: middle;">
									<input type="hidden" name="list[<?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_id'];?>
][0]" value="0" <?php if ($_smarty_tpl->tpl_vars['value']->value['virtualserver_status']=="offline"){?>disabled<?php }?> />
									<input type="checkbox" name="list[<?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_id'];?>
][0]" value="1" <?php if ($_smarty_tpl->tpl_vars['value']->value['virtualserver_weblist_enabled']==1){?>checked<?php }?> <?php if ($_smarty_tpl->tpl_vars['value']->value['virtualserver_status']=="offline"){?>disabled<?php }?> />
								</td>
							</tr>
						<?php }} ?>
					<?php }?>
				</table>
				<input type="submit" class="btn btn-block btn-flat btn-info" value="<?php echo $_smarty_tpl->getVariable('lang')->value['edit'];?>
" />
			</form>
		</div>
	</div>
	<?php }?>
</section>