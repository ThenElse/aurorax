<?php /* Smarty version Smarty3rc4, created on 2018-02-05 03:07:27
         compiled from "C:\localhost\www\Ts3WebPanel\gelistir2\templates/mrstipfan/serverview.tpl" */ ?>
<?php /*%%SmartyHeaderCode:136925a77ca6f4dba75-61589602%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '22d1ffe07a3e9f4277ca846232c9e75425167927' => 
    array (
      0 => 'C:\\localhost\\www\\Ts3WebPanel\\gelistir2\\templates/mrstipfan/serverview.tpl',
      1 => 1517800044,
    ),
  ),
  'nocache_hash' => '136925a77ca6f4dba75-61589602',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_modifier_date_format')) include 'C:\localhost\www\Ts3WebPanel\gelistir2\libs\Smarty\libs\plugins\modifier.date_format.php';
?><?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_info_view'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_info_view'])){?>
<section class="content container-fluid">
	<div class="row">
		<div class="col-xs-12 col-xs-offset-0 col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3 col-lg-4 col-lg-offset-4">
			<div class="box box-danger">
				<div class="box-header"><h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['error'];?>
</h3></div>
				<div class="box-body">
					<p class="lead"><?php echo $_smarty_tpl->getVariable('lang')->value['nopermissions'];?>
</p>
				</div>
			</div>
		</div>
	</div>
</section>
<?php }else{ ?>
<section class="content-header">
	<h1>
		<?php echo $_smarty_tpl->getVariable('lang')->value['virtualserver'];?>
 #<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_id'];?>

	</h1>
</section>
<section class="content container-fluid">
	<div class="row">
		<div class="col-xs-12 col-xs-offset-0 col-sm-10 col-sm-offset-1 col-md-10 col-md-offset-1 col-xs-12 col-xs-offset-0 col-sm-10 col-sm-offset-1 col-md-10 col-md-offset-1 col-lg-10 col-lg-offset-1">
		<?php if (!empty($_smarty_tpl->getVariable('error')->value)){?>
			<div class="alert alert-danger"><?php echo $_smarty_tpl->getVariable('error')->value;?>
</div>
		<?php }?>
		<?php if (!empty($_smarty_tpl->getVariable('noerror')->value)){?>
			<div class="alert alert-info"><?php echo $_smarty_tpl->getVariable('noerror')->value;?>
</div>
		<?php }?>
		<?php if ($_smarty_tpl->getVariable('newserverversion')->value!==true&&!empty($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_version'])){?>
			<div class="alert alert-warning"><?php echo $_smarty_tpl->getVariable('lang')->value['serverupdateav'];?>
<?php echo $_smarty_tpl->getVariable('newserverversion')->value;?>
</div>
		<?php }?>
			<div class="box box-border-teal" data-name="serverview_msgtoall">
				<div class="box-header">
					<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['msgtoserver'];?>
</h3>
					<div class="box-tools pull-right">
						<button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Daraltma"><i class="fa fa-minus"></i></button>
					</div>
				</div>
				<form class="box-body" method="post" action="index.php?site=serverview&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
					<div class="form-group">
						<textarea type="text" class="form-control resize-vert" name="msgtoall" id="msgtoall"></textarea>
					</div>
					<input class="btn btn-flat bg-teal pull-right" type="submit" name="sendmsg" value="<?php echo $_smarty_tpl->getVariable('lang')->value['send'];?>
" />
				</form>
			</div>
			<div class="row">
				<div class="col-xs-12 col-md-6">
					<form method="post" action="index.php?site=serverview&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
						<input type="hidden" name="sid" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_id'];?>
" />
						<input class="btn btn-success btn-flat btn-block" type="submit" name="start" value="<?php echo $_smarty_tpl->getVariable('lang')->value['start'];?>
" />
					</form>
					<a class="btn btn-warning btn-flat btn-block" href="ts3server://ts3.hepoyuncu.com">MSFV3 - TeamSpeak3 Serverine Bağlan</a> 
				</div>
				<div class="col-xs-12 col-md-6">
					<form method="post" action="index.php?site=serverview&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
						<input type="hidden" name="sid" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_id'];?>
" />
						<input class="btn btn-danger btn-flat btn-block" type="submit" name="stop" value="<?php echo $_smarty_tpl->getVariable('lang')->value['stop'];?>
" onclick="return confirm('<?php echo $_smarty_tpl->getVariable('lang')->value['stopservermsg'];?>
')" />
					</form>
					<a class="btn btn-warning btn-flat btn-block" href="ts3server://<?php echo $_SESSION['server_ip'];?>
:<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_port'];?>
"><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_name'];?>
 TeamSpeak3 Server'e Bağlan</a> 
				</div>
			</div>
			<br />
			<div class="row">
				<div class="col-md-6">
					<div class="box box-primary" data-name="serverview_basics">
						<div class="box-header">
							<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['basics'];?>
</h3>
							<div class="box-tools pull-right">
								<button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Daraltma"><i class="fa fa-minus"></i></button>
							</div>
						</div>
						<div class="box-body">
							<div class="table-responsive">
								<table class="table table-striped table-td-no-padding table-vert-mid">
									<tr>
										<th class="col-xs-6 col-sm-6 col-md-6 col-lg-6"><?php echo $_smarty_tpl->getVariable('lang')->value['autostart'];?>
:</th>
										<td>
										<?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_autostart']==1){?>
											<span class="text-green"><?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>
</span>
										<?php }else{ ?>
											<span class="text-red"><?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>
</span>
										<?php }?>
										</td>
									</tr>
									<tr>
										<th><?php echo $_smarty_tpl->getVariable('lang')->value['serveraddress'];?>
:</th>
										<td><?php echo $_SESSION['server_ip'];?>
:<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_port'];?>
</td>
									</tr>
									<tr>
										<th><?php echo $_smarty_tpl->getVariable('lang')->value['minclientversion'];?>
:</th>
										<td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_min_client_version'];?>
</td>
									</tr>
									<tr>
										<th><?php echo $_smarty_tpl->getVariable('lang')->value['uniqueid'];?>
:</th>
										<td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_unique_identifier'];?>
</td>
									</tr>
									<tr>
										<th><?php echo $_smarty_tpl->getVariable('lang')->value['name'];?>
:</th>
										<td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_name'];?>
</td>
									</tr>
									<tr>
										<th><?php echo $_smarty_tpl->getVariable('lang')->value['welcomemsg'];?>
:</th>
										<td class="col-no-white-space"><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_welcomemessage'];?>
</td>
									</tr>
									<tr>
										<th><?php echo $_smarty_tpl->getVariable('lang')->value['version'];?>
:</th>
										<td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_version'];?>
</td>
									</tr>
									<tr>
										<th><?php echo $_smarty_tpl->getVariable('lang')->value['platform'];?>
:</th>
										<td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_platform'];?>
</td>
									</tr>
									<tr>
										<th><?php echo $_smarty_tpl->getVariable('lang')->value['created'];?>
:</th>
										<td><?php echo smarty_modifier_date_format($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_created'],"%d.%m.%Y - %H:%M:%S");?>
</td>
									</tr>
									<tr>
										<th><?php echo $_smarty_tpl->getVariable('lang')->value['status'];?>
:</th>
										<td>
											<?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_status']=="online"){?>
												<span class="btn btn-flat btn-xs btn-success disabled"><?php echo $_smarty_tpl->getVariable('lang')->value['online'];?>
</span>
											<?php }elseif($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_status']=="online virtual"){?>
												<span class="btn btn-flat btn-xs btn-primary disabled"><?php echo $_smarty_tpl->getVariable('lang')->value['onlinevirtual'];?>
</span>
											<?php }elseif($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_status']=="offline"){?>
												<span class="btn btn-flat btn-xs btn-danger disabled"><?php echo $_smarty_tpl->getVariable('lang')->value['offline'];?>
</span>
											<?php }?>
										</td>
									</tr>
									<tr>
										<th><?php echo $_smarty_tpl->getVariable('lang')->value['runtime'];?>
:</th>
										<td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_uptime'];?>

										</td>
									</tr>
									<tr>
										<th><?php echo $_smarty_tpl->getVariable('lang')->value['clients'];?>
:</th>
										<td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_clientsonline']-$_smarty_tpl->getVariable('serverinfo')->value['virtualserver_queryclientsonline'];?>
 / <?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_maxclients'];?>
</td>
									</tr>
									<tr>
										<th><?php echo $_smarty_tpl->getVariable('lang')->value['queryclients'];?>
:</th>
										<td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_queryclientsonline'];?>
</td>
									</tr>
									<tr>
										<th><?php echo $_smarty_tpl->getVariable('lang')->value['maxreservedslots'];?>
:</th>
										<td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_reserved_slots'];?>
</td>
									</tr>
									<tr>
										<th><?php echo $_smarty_tpl->getVariable('lang')->value['showonweblist'];?>
:</th>
										<td>
										<?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_weblist_enabled']==1){?>
											<span class="text-green"><?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>
</span>
										<?php }else{ ?>
											<span class="text-red"><?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>
</span>
										<?php }?>				
										</td>
									</tr>
									<tr>
										<th><?php echo $_smarty_tpl->getVariable('lang')->value['codecencryptionmode'];?>
:</th>
										<td>
										<?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_codec_encryption_mode']==0){?>
											<?php echo $_smarty_tpl->getVariable('lang')->value['codecencryptionmodeindi'];?>

										<?php }elseif($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_codec_encryption_mode']==1){?>
											<span class="text-red"><?php echo $_smarty_tpl->getVariable('lang')->value['codecencryptionmodegoff'];?>
</span>
										<?php }elseif($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_codec_encryption_mode']==2){?>
											<span class="text-green"><?php echo $_smarty_tpl->getVariable('lang')->value['codecencryptionmodegon'];?>
</span>
										<?php }?>
										</td>
									</tr>
									<tr>
										<th><?php echo $_smarty_tpl->getVariable('lang')->value['channel'];?>
:</th>
										<td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_channelsonline'];?>
</td>
									</tr>
									<tr>
										<th><?php echo $_smarty_tpl->getVariable('lang')->value['minclientschan'];?>
:</th>
										<td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_min_clients_in_channel_before_forced_silence'];?>
</td>
									</tr>
									<tr>
										<th><?php echo $_smarty_tpl->getVariable('lang')->value['clientsdimm'];?>
:</th>
										<td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_priority_speaker_dimm_modificator'];?>
</td>
									</tr>
									<tr>
										<th><?php echo $_smarty_tpl->getVariable('lang')->value['passwordset'];?>
:</th>
										<td>
										<?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_flag_password']==1){?>
											<span class="text-green"><?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>
</span>
										<?php }else{ ?>
											<span class="text-red"><?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>
</span>
										<?php }?>
										</td>
									</tr>
									<tr>
										<th><?php echo $_smarty_tpl->getVariable('lang')->value['securitylevel'];?>
:</th>
										<td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_needed_identity_security_level'];?>
</td>
									</tr>
									<tr>
										<th><?php echo $_smarty_tpl->getVariable('lang')->value['iconid'];?>
:</th>
										<td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_icon_id'];?>
</td>
									</tr>
								</table>
							</div>
						</div>
					</div>
					<div class="box box-info" data-name="serverview_host">
						<div class="box-header">
							<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['host'];?>
</h3>
							<div class="box-tools pull-right">
								<button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Daraltma"><i class="fa fa-minus"></i></button>
							</div>
						</div>
						<div class="box-body">
							<table class="table table-striped table-td-no-padding table-vert-mid">
								<tr>
									<th class="col-xs-6 col-sm-6 col-md-6 col-lg-6"><?php echo $_smarty_tpl->getVariable('lang')->value['hostmessage'];?>
:</td>
									<td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostmessage'];?>
</td>
								</tr>
								<tr>
									<th><?php echo $_smarty_tpl->getVariable('lang')->value['hostmessageshow'];?>
:</th>
									<td>
									<?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostmessage_mode']=='0'){?>
										<?php echo $_smarty_tpl->getVariable('lang')->value['nomessage'];?>

										<?php }elseif($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostmessage_mode']=='1'){?>
										<?php echo $_smarty_tpl->getVariable('lang')->value['showmessagelog'];?>

										<?php }elseif($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostmessage_mode']=='2'){?>
										<?php echo $_smarty_tpl->getVariable('lang')->value['showmodalmessage'];?>

										<?php }elseif($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostmessage_mode']=='3'){?>
										<?php echo $_smarty_tpl->getVariable('lang')->value['modalandexit'];?>

									<?php }?>
									</td>
								</tr>
								<tr>
									<td colspan="2">&nbsp;</td>
								</tr>
								<tr>
									<th><?php echo $_smarty_tpl->getVariable('lang')->value['hosturl'];?>
:</th>
									<td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostbanner_url'];?>
</td>
								</tr>
								<tr>
									<th><?php echo $_smarty_tpl->getVariable('lang')->value['hostbannerurl'];?>
:</th>
									<td>
									<?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostbanner_gfx_url']!=''){?>
									<img style="width:350px" src="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostbanner_gfx_url'];?>
" alt="" /><br />
									<?php }?>
									<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostbanner_gfx_url'];?>
</td>
								</tr>
								<tr>
									<th><?php echo $_smarty_tpl->getVariable('lang')->value['hostbannerintval'];?>
:</th>
									<td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostbanner_gfx_interval'];?>
</td>
								</tr>
								<tr>
									<td colspan="2">&nbsp;</td>
								</tr>
								<tr>
									<th><?php echo $_smarty_tpl->getVariable('lang')->value['hostbuttongfx'];?>
:</th>
									<td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostbutton_gfx_url'];?>
</td>
								</tr>
								<tr>
									<th><?php echo $_smarty_tpl->getVariable('lang')->value['hostbuttontooltip'];?>
:</th>
									<td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostbutton_tooltip'];?>
</td>
								</tr>
								<tr>
									<th><?php echo $_smarty_tpl->getVariable('lang')->value['hostbuttonurl'];?>
:</th>
									<td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostbutton_url'];?>
</td>
								</tr>
							</table>
						</div>
					</div>
					<div class="box box-border-olive" data-name="serverview_standardgroups">
						<div class="box-header">
							<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['standardgroups'];?>
</h3>
							<div class="box-tools pull-right">
								<button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Daraltma"><i class="fa fa-minus"></i></button>
							</div>
						</div>
						<div class="box-body">
							<table class="table table-striped table-td-no-padding table-vert-mid">
								<tr>
									<th class="col-xs-6 col-sm-6 col-md-6 col-lg-6"><?php echo $_smarty_tpl->getVariable('lang')->value['servergroup'];?>
:</th>
									<td>
									<?php if (!empty($_smarty_tpl->getVariable('servergroups')->value)){?>
										<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('servergroups')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
											<?php if ($_smarty_tpl->tpl_vars['value']->value['sgid']==$_smarty_tpl->getVariable('serverinfo')->value['virtualserver_default_server_group']){?>
												(<?php echo $_smarty_tpl->tpl_vars['value']->value['sgid'];?>
) <?php echo $_smarty_tpl->tpl_vars['value']->value['name'];?>

											<?php }?>
										<?php }} ?>
									<?php }?>
									</td>
								</tr>
								<tr>
									<th><?php echo $_smarty_tpl->getVariable('lang')->value['channelgroup'];?>
:</th>
									<td>
									<?php if (!empty($_smarty_tpl->getVariable('channelgroups')->value)){?>
										<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('channelgroups')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
											<?php if ($_smarty_tpl->tpl_vars['value']->value['cgid']==$_smarty_tpl->getVariable('serverinfo')->value['virtualserver_default_channel_group']){?>
												(<?php echo $_smarty_tpl->tpl_vars['value']->value['cgid'];?>
) <?php echo $_smarty_tpl->tpl_vars['value']->value['name'];?>

											<?php }?>
										<?php }} ?>
									<?php }?>
									</td>
								</tr>
								<tr>
									<th><?php echo $_smarty_tpl->getVariable('lang')->value['chanadmingroup'];?>
:</th>
									<td>
									<?php if (!empty($_smarty_tpl->getVariable('channelgroups')->value)){?>
										<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('channelgroups')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
											<?php if ($_smarty_tpl->tpl_vars['value']->value['cgid']==$_smarty_tpl->getVariable('serverinfo')->value['virtualserver_default_channel_admin_group']){?>
												(<?php echo $_smarty_tpl->tpl_vars['value']->value['cgid'];?>
) <?php echo $_smarty_tpl->tpl_vars['value']->value['name'];?>

											<?php }?>
										<?php }} ?>
									<?php }?>
									</td>
								</tr>
							</table>
						</div>
					</div>
					<div class="box box-warning" data-name="serverview_autoban">
						<div class="box-header">
							<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['autoban'];?>
</h3>
							<div class="box-tools pull-right">
								<button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Daraltma"><i class="fa fa-minus"></i></button>
							</div>
						</div>
						<div class="box-body">
							<table class="table table-striped table-td-no-padding table-vert-mid">
								<tr>
									<th class="col-xs-6 col-sm-6 col-md-6 col-lg-6"><?php echo $_smarty_tpl->getVariable('lang')->value['autobancount'];?>
:</td>
									<td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_complain_autoban_count'];?>
</td>
								</tr>
								<tr>
									<th><?php echo $_smarty_tpl->getVariable('lang')->value['autobantime'];?>
:</th>
									<td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_complain_autoban_time'];?>
</td>
								</tr>
								<tr>
									<th><?php echo $_smarty_tpl->getVariable('lang')->value['removetime'];?>
:</th>
									<td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_complain_remove_time'];?>
</td>
								</tr>
							</table>
						</div>
					</div>
					<div class="box box-danger" data-name="serverview_antiflood">
						<div class="box-header">
							<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['antiflood'];?>
</h3>
							<div class="box-tools pull-right">
								<button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Daraltma"><i class="fa fa-minus"></i></button>
							</div>
						</div>
						<div class="box-body">
							<table class="table table-striped table-td-no-padding table-vert-mid">
								<tr>
									<th class="col-xs-6 col-sm-6 col-md-6 col-lg-6"><?php echo $_smarty_tpl->getVariable('lang')->value['pointstickreduce'];?>
:</td>
									<td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_antiflood_points_tick_reduce'];?>
</td>
								</tr>
								<tr>
									<th><?php echo $_smarty_tpl->getVariable('lang')->value['pointsneededblockcmd'];?>
:</th>
									<td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_antiflood_points_needed_command_block'];?>
</td>
								</tr>
								<tr>
									<th><?php echo $_smarty_tpl->getVariable('lang')->value['pointsneededblockip'];?>
:</th>
									<td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_antiflood_points_needed_ip_block'];?>
</td>
								</tr>
							</table>
						</div>
					</div>
					<div class="box box-success" data-name="serverview_transfers">
						<div class="box-header">
							<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['transfers'];?>
</h3>
							<div class="box-tools pull-right">
								<button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Daraltma"><i class="fa fa-minus"></i></button>
							</div>
						</div>
						<div class="box-body">
							<table class="table table-striped table-td-no-padding table-vert-mid">
								<tr>
									<th class="col-xs-6 col-sm-6 col-md-6 col-lg-6"><?php echo $_smarty_tpl->getVariable('lang')->value['upbandlimit'];?>
:</td>
									<td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_max_upload_total_bandwidth'];?>
 Byte/s</td>
								</tr>
								<tr>
									<th><?php echo $_smarty_tpl->getVariable('lang')->value['uploadquota'];?>
:</th>
									<td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_upload_quota'];?>
 MiB</td>
								</tr>
								<tr>
									<th><?php echo $_smarty_tpl->getVariable('lang')->value['downbandlimit'];?>
:</th>
									<td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_max_download_total_bandwidth'];?>
 Byte/s</td>
								</tr>
								<tr>
									<th><?php echo $_smarty_tpl->getVariable('lang')->value['downloadquota'];?>
:</th>
									<td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_download_quota'];?>
 MiB</td>
								</tr>
							</table>
						</div>
					</div>
					<div class="box box-default" data-name="serverview_logs">
						<div class="box-header">
							<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['logs'];?>
</h3>
							<div class="box-tools pull-right">
								<button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Daraltma"><i class="fa fa-minus"></i></button>
							</div>
						</div>
						<div class="box-body">
							<table class="table table-striped table-td-no-padding table-vert-mid">
								<tr>
									<th class="col-xs-6 col-sm-6 col-md-6 col-lg-6"><?php echo $_smarty_tpl->getVariable('lang')->value['logclient'];?>
:</td>
									<td>
									<?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_log_client']==1){?>
										<span class="text-green"><?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>
</span>
									<?php }else{ ?>
										<span class="text-red"><?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>
</span>
									<?php }?>
									</td>
								</tr>
								<tr>
									<th><?php echo $_smarty_tpl->getVariable('lang')->value['logquery'];?>
:</th>
									<td>
									<?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_log_query']==1){?>
										<span class="text-green"><?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>
</span>
									<?php }else{ ?>
										<span class="text-red"><?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>
</span>
									<?php }?>
									</td>
								</tr>
								<tr>
									<th><?php echo $_smarty_tpl->getVariable('lang')->value['logchannel'];?>
:</th>
									<td>
									<?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_log_channel']==1){?>
										<span class="text-green"><?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>
</span>
									<?php }else{ ?>
										<span class="text-red"><?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>
</span>
									<?php }?>
									</td>
								</tr>
								<tr>
									<th><?php echo $_smarty_tpl->getVariable('lang')->value['logpermissions'];?>
:</th>
									<td>
									<?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_log_permissions']==1){?>
										<span class="text-green"><?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>
</span>
									<?php }else{ ?>
										<span class="text-red"><?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>
</span>
									<?php }?>
									</td>
								</tr>
								<tr>
									<th><?php echo $_smarty_tpl->getVariable('lang')->value['logserver'];?>
:</th>
									<td>
									<?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_log_server']==1){?>
										<span class="text-green"><?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>
</span>
									<?php }else{ ?>
										<span class="text-red"><?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>
</span>
									<?php }?>	
									</td>
								</tr>
								<tr>
									<th><?php echo $_smarty_tpl->getVariable('lang')->value['logfiletransfer'];?>
:</th>
									<td>
									<?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_log_filetransfer']==1){?>
										<span class="text-green"><?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>
</span>
									<?php }else{ ?>
										<span class="text-red"><?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>
</span>
									<?php }?>	
									</td>
								</tr>
							</table>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="box box-border-maroon" data-name="serverview_ts3viewer">
						<div class="box-header">
							<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['ts3sunucu'];?>
</h3>
							<div class="box-tools pull-right">
								<button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Daraltma"><i class="fa fa-minus"></i></button>
							</div>
						</div>
						<div class="box-body">
							<?php echo $_smarty_tpl->getVariable('tree')->value;?>

						</div>
						<div class="box-footer">						
							<?php echo $_smarty_tpl->getVariable('lang')->value['tsviewpubhtml'];?>

							<textarea rows="5" class="form-control resize-vert" readonly><?php echo $_smarty_tpl->getVariable('pubtsview')->value;?>
</textarea>
						</div>
					</div>
				</div>
			</div>
			<?php }?>
		</div>
	</div>
</section>