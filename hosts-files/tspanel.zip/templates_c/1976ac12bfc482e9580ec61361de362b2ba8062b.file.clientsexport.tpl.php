<?php /* Smarty version Smarty3rc4, created on 2018-02-05 01:49:44
         compiled from "C:\localhost\www\Ts3WebPanel\gelistir2\templates/mrstipfan/clientsexport.tpl" */ ?>
<?php /*%%SmartyHeaderCode:72445a77b8385a1ab4-79705159%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1976ac12bfc482e9580ec61361de362b2ba8062b' => 
    array (
      0 => 'C:\\localhost\\www\\Ts3WebPanel\\gelistir2\\templates/mrstipfan/clientsexport.tpl',
      1 => 1513634812,
    ),
  ),
  'nocache_hash' => '72445a77b8385a1ab4-79705159',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<section class="content container-fluid">
	<div class="col-xs-12 col-xs-offset-0 col-sm-10 col-sm-offset-1 col-md-10 col-md-offset-1 col-lg-10 col-lg-offset-1 no-padding">
		<div class="box box-primary">
			<div class="box-header">
				<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['clientsexport'];?>
</h3>
			</div>
			<div class="box-body">
				<p><?php echo $_smarty_tpl->getVariable('lang')->value['clientsexportdesc'];?>
</p>
				<form method="post" action="site/clientsexport.php" target="_blank">
					<input type="hidden" name="sid" value="<?php echo $_smarty_tpl->getVariable('sid')->value;?>
" />
					<input class="btn btn-primary btn-flat btn-block" type="submit" name="give" value="<?php echo $_smarty_tpl->getVariable('lang')->value['clientsexport'];?>
" />					
				</form>
			</div>
		</div>
	</div>
</section>