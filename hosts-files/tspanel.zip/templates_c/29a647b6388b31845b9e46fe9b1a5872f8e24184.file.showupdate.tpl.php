<?php /* Smarty version Smarty3rc4, created on 2018-02-05 01:40:34
         compiled from "C:\localhost\www\Ts3WebPanel\gelistir2\templates/new/showupdate.tpl" */ ?>
<?php /*%%SmartyHeaderCode:226805a77b6122a6635-66051227%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '29a647b6388b31845b9e46fe9b1a5872f8e24184' => 
    array (
      0 => 'C:\\localhost\\www\\Ts3WebPanel\\gelistir2\\templates/new/showupdate.tpl',
      1 => 1467056337,
    ),
  ),
  'nocache_hash' => '226805a77b6122a6635-66051227',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (isset($_smarty_tpl->getVariable('newwiversion')->value)){?>
<tr>
	<td class="green1 warning center" colspan="2">
	<?php echo $_smarty_tpl->getVariable('newwiversion')->value;?>

	</td>
<tr>
<?php }?>