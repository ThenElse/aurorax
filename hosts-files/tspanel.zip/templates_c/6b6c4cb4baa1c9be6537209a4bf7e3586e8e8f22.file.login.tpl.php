<?php /* Smarty version Smarty3rc4, created on 2018-02-05 01:53:12
         compiled from "C:\localhost\www\Ts3WebPanel\gelistir2\templates/mrstipfan/login.tpl" */ ?>
<?php /*%%SmartyHeaderCode:274795a77b908596805-25407828%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6b6c4cb4baa1c9be6537209a4bf7e3586e8e8f22' => 
    array (
      0 => 'C:\\localhost\\www\\Ts3WebPanel\\gelistir2\\templates/mrstipfan/login.tpl',
      1 => 1517327346,
    ),
  ),
  'nocache_hash' => '274795a77b908596805-25407828',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_smarty_tpl->getVariable('loginstatus')->value===true){?>
<section class="content container-fluid">
<?php }?>
<?php if (!empty($_smarty_tpl->getVariable('error')->value)){?>
	<div class="alert alert-danger"><?php echo $_smarty_tpl->getVariable('error')->value;?>
</div>
<?php }?>
<?php if (!empty($_smarty_tpl->getVariable('motd')->value)){?>
	<div class="alert alert-warning">
		<b><?php echo $_smarty_tpl->getVariable('lang')->value['motd'];?>
</b><br />
		<p><?php echo $_smarty_tpl->getVariable('motd')->value;?>
</p>
	</div>
<?php }?>
<?php if (!isset($_POST['sendlogin'])&&$_smarty_tpl->getVariable('loginstatus')->value!==true){?>
	<form method="post" action="index.php?site=login">
		<div class="form-group has-feedback">
		<?php if (count($_smarty_tpl->getVariable('instances')->value)==1){?>
			<?php  $_smarty_tpl->tpl_vars['sdata'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['skey'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('instances')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['sdata']->key => $_smarty_tpl->tpl_vars['sdata']->value){
 $_smarty_tpl->tpl_vars['skey']->value = $_smarty_tpl->tpl_vars['sdata']->key;
?>
				<select class="form-control" name="skey" disabled>
					<option value="<?php echo $_smarty_tpl->tpl_vars['skey']->value;?>
" disabled selected><?php echo $_smarty_tpl->tpl_vars['sdata']->value['alias'];?>
</option>	
				</select>
				<input type="hidden" name="skey" value="<?php echo $_smarty_tpl->tpl_vars['skey']->value;?>
" />
			<?php }} ?>
		<?php }else{ ?>
			<select class="form-control" name="skey" required>
			<?php  $_smarty_tpl->tpl_vars['sdata'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['skey'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('instances')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['sdata']->key => $_smarty_tpl->tpl_vars['sdata']->value){
 $_smarty_tpl->tpl_vars['skey']->value = $_smarty_tpl->tpl_vars['sdata']->key;
?>
				<option value="<?php echo $_smarty_tpl->tpl_vars['skey']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['sdata']->value['alias'];?>
</option>	
			<?php }} ?>
			</select>
		<?php }?>
		</div>
		<div class="form-group has-feedback">
			<input type="text" class="form-control" name="loginUser" value="hizmet" title="<?php echo $_smarty_tpl->getVariable('lang')->value['username'];?>
" required>
			<span class="glyphicon glyphicon-user form-control-feedback"></span>
		</div>
		<div class="form-group has-feedback">
			<input type="password" class="form-control" name="loginPw" title="<?php echo $_smarty_tpl->getVariable('lang')->value['password'];?>
" required>
			<span class="glyphicon glyphicon-lock form-control-feedback"></span>
		</div>
		<input type="submit" class="btn btn-success btn-block btn-flat" name="sendlogin" value="<?php echo $_smarty_tpl->getVariable('lang')->value['login'];?>
" />
	</form>
<?php }?>
<?php if ($_smarty_tpl->getVariable('loginstatus')->value===true){?>
</section>
<?php }?>