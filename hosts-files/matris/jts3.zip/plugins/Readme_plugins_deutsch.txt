Kurze Plugin Dokumentation

-= Warnung =-
Plugins können gefährlich sein, denn diese haben Zugriff auf das System, auf dem der JTS3ServerMod Prozess läuft,
zum Teamspeak 3 Server und (wenn verwendet) der MySQL Datenbank.
Daher verwende Plugins nur von Personen, denen man vertrauen kann oder nachdem der Quellcode überprüft wurde.
Der Autor vom JTS3ServerMod ist nicht verantwortlich für irgendwelche Schäden oder Datenverlust!


-= Benutzung von Plugins =-
Plugins werden als Bot Funktion bei bot_functions in der primären Bot Konfigurationsdatei JTS3ServerMod_server.cfg gesetzt.
Setze den Dateinamen des Plugins als Funktionsklasse. Beispiel: AutoKickTimer.jar:akt
Wenn MySQL verwendet wird, muss es entsprechend in der MySQL Datenbank bei den Bot Einstellungen gesetzt werden.

Wenn das offizielle JTS3ServerMod Web Interface verwendet wird,
muss eine SQL Datei vom Plugin in die MySQL Datenbank importiert werden.

In dem Fall, dass das AutoKickTimer Plugin mit dem offiziellen JTS3ServerMod Web Interface konfiguriert werden soll,
muss die beiliegende Datei AutoKickTimer.sql in die MySQL Datenbank vom Web Interface importiert werden.


-= Erstelle eigene Plugins =-
Falls das "Eclipse IDE for Java Developers" verwendet werden soll, verwende gerne mein How To:
http://www.stefan1200.de/documentation/jts3servermod/jts3servermod_plugindevelopment/index.html

Vollständige API Dokumentation sind im JTS3ServerMod Ordner unter (nur in Englisch):
documents\Plugin_API\index.html

Plugin API Quellcode/Schnittstellen sind im JTS3ServerMod Ordner unter:
documents\plugin_sources\plugin_api_src.zip

Plugin API Binärdateien (kann als Bibliothek im IDE hinzugefügt werden) sind im JTS3ServerMod Ordner unter:
documents\plugin_sources\plugin_api_bin.zip

Beispiel Quellcode von der AutoKickTimer.jar sind im JTS3ServerMod Ordner unter:
documents\plugin_sources\AutoKickTimer_src.zip

Nur als Tipp: Jedes Plugin muss das HandleBotEvents Interface einbinden.
Deshalb sollte man mit einer leeren Klasse (inklusive einer leeren main Methode) beginnen
und das HandleBotEvents Interface (inklusive dessen Methoden) einbinden
und damit etwas herum experimentieren, um zu verstehen wie alles funktioniert.
Später füge einfach weitere Interfaces hinzu, die benötigt werden, um das Ziel zu erreichen.

Wenn das eigene Plugin in eine Jar Datei exportiert wird, stelle sicher, das nur die eigenen Klassen/Dateien exportiert werden.
Die Klassen von der plugin_api_src.zip dürfen sich nicht in der Jar Datei vom Plugin befinden!
Setze die Klasse vom Plugin, die das HandleBotEvents Interface implementiert, als Main-Class in der MANIFEST.MF von der Jar Datei.
Programme, wie Eclipse, machen dies auch direkt über den JAR Export Assistenten.
Es ist empfohlen beim Java Compiler die source und target Argumente auf Version 1.5 (Java 5) zu setzen,
so wurde auch der JTS3ServerMod kompiliert. Dies kann in den Projekteinstellungen der meisten IDEs gesetzt werden.

Einige Dinge müssen erledigt werden, wenn das JTS3ServerMod Web Interface das Plugin unterstützen soll.
Im Moment ist noch nicht alles dokumentiert, aber lese die Beschreibungen unten und
schaue in die AutoKickTimer.sql Datei, um eine Ahnung zu bekommen, wie es funktioniert.
Das Ergebnis der AutoKickTimer.sql ist im Bild AutoKickTimer_WebInterface.png zu sehen.

Tabelle jts3servermodwebui_botfunction, Beschreibung der Spalten:
classname -> Dateiname von der jar Datei des Plugins.
multiple_use -> 0 oder 1, wenn mehrfache Nutzung vom Plugin sinnvoll oder erlaubt ist.

Tabelle jts3servermodwebui_functionpage, Beschreibung der Spalten:
configkey -> Konfigschlüssel ohne den Plugin Konfig Prefix.
sortnr -> Nur die Reihenfolge auf der Konfigurationsseite.
groupnext -> Standard ist 0, setze dies auf 1 und keine Trennlinie unter der Einstellung wird hinzugefügt.
typename -> Mögliche Werte: number, channel, channelgroup, servergroup, select, multilinetext, longtext, text
options -> number: Erlaubter Zahlenbereich mit einem Komma getrennt, wie 1,99 um Zahlen zwischen 1 und 99 zu erlauben
options -> channel, channelgroup, servergroup: Wähle die erlaubte Auswahl: single / multiple
options -> select: Alle Auswahlmöglichkeiten mit einem Komma getrennt wie yes,maybe,no

Plugins können gerne auf meinem Forum unter https://www.stefan1200.de veröffentlicht werden.
Beantrage einfach ein kostenloses Benutzerkonto per E-Mail bei info@stefan1200.de