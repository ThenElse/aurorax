package de.stefan1200.jts3servermod;

import java.util.HashMap;
import java.util.StringTokenizer;
import java.util.Vector;

import de.stefan1200.jts3serverquery.JTS3ServerQuery;

public class ClientDatabaseCache
{
	private final String REQUEST_COUNT = "25";
	private final short REQUEST_DELAY = 2000;
	
	private JTS3ServerMod modClass;
	private JTS3ServerQuery queryLib;
	private Vector<String> uniqueID = new Vector<String>();
	private Vector<String> nickname = new Vector<String>();
	private Vector<String> description = new Vector<String>();
	private Vector<Integer> createdAt = new Vector<Integer>();
	private Vector<Integer> lastOnline = new Vector<Integer>();
	private Vector<Integer> databaseID = new Vector<Integer>();
	
	private int currentPosition = 0;
	private boolean updateIsRunning = false;
	
	public ClientDatabaseCache(JTS3ServerQuery queryLib, JTS3ServerMod modClass)
	{
		this.queryLib = queryLib;
		this.modClass = modClass;
		updateCache();
	}
	
	private void updateCache()
	{
		currentPosition = 0;
		
		new Thread(new Runnable()
		{
			public void run()
			{
				modClass.addLogEntry("CACHE_INFO", "Creating client database cache...", true);
				updateIsRunning = true;
				while (updateIsRunning)
				{
					Vector<HashMap<String, String>> clientDBList = queryLib.getList(JTS3ServerQuery.LISTMODE_CLIENTDBLIST, "start=" + Integer.toString(currentPosition) + ",duration=" + REQUEST_COUNT);
					if (clientDBList == null || clientDBList.size() == 0 || !updateIsRunning)
					{
						break;
					}
					
					for (HashMap<String, String> clientInfo : clientDBList)
					{
						try
						{
							if (databaseID.size() <= currentPosition)
							{
								createdAt.addElement(Integer.parseInt(clientInfo.get("client_created")));
								lastOnline.addElement(Integer.parseInt(clientInfo.get("client_lastconnected")));
								databaseID.addElement(Integer.parseInt(clientInfo.get("cldbid")));
								nickname.addElement(clientInfo.get("client_nickname"));
								description.addElement(clientInfo.get("client_description"));
								uniqueID.addElement(clientInfo.get("client_unique_identifier"));
							}
							else
							{
								createdAt.setElementAt(Integer.parseInt(clientInfo.get("client_created")), currentPosition);
								lastOnline.setElementAt(Integer.parseInt(clientInfo.get("client_lastconnected")), currentPosition);
								databaseID.setElementAt(Integer.parseInt(clientInfo.get("cldbid")), currentPosition);
								nickname.setElementAt(clientInfo.get("client_nickname"), currentPosition);
								description.setElementAt(clientInfo.get("client_description"), currentPosition);
								uniqueID.setElementAt(clientInfo.get("client_unique_identifier"), currentPosition);
							}
						}
						catch (NumberFormatException nfe)
						{
							modClass.addLogEntry("CACHE_INFO", "Got invalid information for client \"" + clientInfo.get("client_nickname") + "\", skipping client!", false);
							continue;
						}
						
						++currentPosition;
					}
					
					try
					{
						Thread.sleep(REQUEST_DELAY);
					}
					catch (Exception e)
					{
						break;
					}
				}
				updateIsRunning = false;
				modClass.addLogEntry("CACHE_INFO", "Client database cache created, " + Integer.toString(databaseID.size()) + " clients in cache.", true);
			}
		}).start();
	}
	
	synchronized void updateSingleClient(HashMap<String, String> clientInfo)
	{
		if (updateIsRunning)
		{
			return;
		}
		
		try
		{
			if (Integer.parseInt(clientInfo.get("client_type")) != 0)
			{
				return;
			}
			
			int searchDBID = Integer.parseInt(clientInfo.get("client_database_id"));
			int index = databaseID.indexOf(searchDBID);
			
			if (index >= 0)
			{
				nickname.setElementAt(clientInfo.get("client_nickname"), index);
				lastOnline.setElementAt((int)(System.currentTimeMillis() / 1000), index);
				
				if (clientInfo.get("client_description") != null)
				{
					description.setElementAt(clientInfo.get("client_description"), index);
				}
				
				if (uniqueID.elementAt(index).length() == 0 && clientInfo.get("client_unique_identifier") != null)
				{
					uniqueID.setElementAt(clientInfo.get("client_unique_identifier"), index);
				}
			}
			else
			{
				nickname.addElement(clientInfo.get("client_nickname"));
				description.addElement((clientInfo.get("client_description") == null ? "" : clientInfo.get("client_description")));
				uniqueID.addElement((clientInfo.get("client_unique_identifier") == null ? "" : clientInfo.get("client_unique_identifier")));
				createdAt.addElement((int)(System.currentTimeMillis() / 1000));
				lastOnline.addElement((int)(System.currentTimeMillis() / 1000));
				databaseID.addElement(Integer.parseInt(clientInfo.get("client_database_id")));
			}
		}
		catch (NumberFormatException e)
		{
			modClass.addLogEntry("CACHE_INFO", "Got invalid information for client \"" + clientInfo.get("client_nickname") + "\"!", false);
		}
	}
	
	void updateClientList(Vector<HashMap<String, String>> clientList)
	{
		for (HashMap<String, String> hashMap : clientList)
		{
			updateSingleClient(hashMap);
		}
	}
	
	void stopUpdating()
	{
		updateIsRunning = false;
	}
	
	int getLastOnline(int clientDBID)
	{
		int pos = databaseID.indexOf(clientDBID);
		
		if (pos != -1)
		{
			return lastOnline.elementAt(pos);
		}
		
		return -1;
	}
	
	int getCreatedAt(int clientDBID)
	{
		int pos = databaseID.indexOf(clientDBID);
		
		if (pos != -1)
		{
			return createdAt.elementAt(pos);
		}
		
		return -1;
	}
	
	String getNickname(int clientDBID)
	{
		int pos = databaseID.indexOf(clientDBID);
		
		if (pos != -1)
		{
			return nickname.elementAt(pos);
		}
		
		return null;
	}
	
	String getUniqueID(int clientDBID)
	{
		int pos = databaseID.indexOf(clientDBID);
		
		if (pos != -1)
		{
			return uniqueID.elementAt(pos);
		}
		
		return null;
	}
	
	String getDescription(int clientDBID)
	{
		int pos = databaseID.indexOf(clientDBID);
		
		if (pos != -1)
		{
			return description.elementAt(pos);
		}
		
		return null;
	}
	
	boolean isUpdateRunning()
	{
		return updateIsRunning;
	}
	
	Vector<Integer> searchInactiveClients(int daysInactive)
	{
		if (updateIsRunning)
		{
			return null;
		}
		
		if (daysInactive < 10)
		{
			return null;
		}
		
		long daysInactiveSeconds = (System.currentTimeMillis() / 1000) - (daysInactive * (60 * 60 * 24));
		Vector<Integer> result = new Vector<Integer>();
		
		for (int i = 0; i < lastOnline.size(); i++)
		{
			if (lastOnline.elementAt(i) < daysInactiveSeconds)
			{
				result.addElement(databaseID.elementAt(i));
			}
		}
		
		return result;
	}
	
	Vector<Integer> searchClientNickname(String search)
	{
		if (updateIsRunning)
		{
			return null;
		}
		
		if (search == null)
		{
			return null;
		}
		
		Vector<Integer> result = new Vector<Integer>();
		try
		{
			String clientnameTemp = search.replace("*", "");
			if (clientnameTemp.length() < 3)
			{
				return null;
			}
			
			boolean startsWith = search.startsWith("*");
			boolean endsWith = search.endsWith("*");
			
			StringTokenizer st = new StringTokenizer(search, "*", false);
			Vector<String> parts = new Vector<String>();
			
			String tmp;
			while (st.hasMoreTokens())
			{
				tmp = st.nextToken();
				if (tmp.length() > 0)
				{
					parts.addElement(tmp.toLowerCase());
				}
			}
			
			String tmpPart;
			int pos = -1;
			for (int i=0; i<nickname.size(); i++)
			{
				tmp = nickname.elementAt(i).toLowerCase();
				pos = 0;
				
				for (int x=0; x<parts.size(); x++)
				{
					tmpPart = parts.elementAt(x);
					if (parts.size() == 1)
					{
						if (tmp.equalsIgnoreCase(tmpPart))
						{
							result.addElement(databaseID.elementAt(i));
							break;
						}
						else if (!startsWith && !endsWith)
						{
							break;
						}
					}
					
					if (x == 0 && !startsWith)
					{
						if (tmp.startsWith(tmpPart))
						{
							pos = tmpPart.length();
							if (x == (parts.size() - 1))
							{
								result.addElement(databaseID.elementAt(i));
							}
							continue;
						}
						else
						{
							break;
						}
					}
					else if (x == (parts.size() - 1) && !endsWith)
					{
						if (tmp.endsWith(tmpPart))
						{
							result.addElement(databaseID.elementAt(i));
							break;
						}
						else
						{
							break;
						}
					}
					
					pos = tmp.indexOf(tmpPart, pos);
					
					if (pos == -1)
					{
						break;
					}
					else
					{
						pos += tmpPart.length();
						
						if (x == (parts.size() - 1))
						{
							result.addElement(databaseID.elementAt(i));
						}
					}
				}
			}
		}
		catch (Exception e)
		{
			
		}
		
		return result;
	}
}
