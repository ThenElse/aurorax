package de.stefan1200.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Properties;
import java.util.Vector;

/**
 * ArrangedPropertiesWriter allows you to write a formatted property file with help texts for every key.
 * 
 * You are allowed to use this file for free, but it would be nice to be named in the credits of your project.
 * The author of this class is not responsible for any damage or data loss!
 * It is not allowed to sell this class for money, it has to be free to get!
 * 
 * Homepage: http://www.stefan1200.de
 * 
 * @author Stefan Martens
 * @version 1.0 (19.02.2010)
 */
public class ArrangedPropertiesWriter
{
	private final String SEPARATOR = "***";
	private final String LINE_SEPARATOR = System.getProperty("line.separator");
	private HashMap<String, String> hmHelp = new HashMap<String, String>();
	private HashMap<String, String> hmValue = new HashMap<String, String>();
	private Vector<String> vKeys = new Vector<String>();
	private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	
	/**
	 * Add a new key at the current position.
	 * @param key Name of the key
	 * @param helpText Help text of the key or <code>null</code> if not wanted.
	 * @return <code>true</code> if the key was added, <code>false</code> if the key is already known.
	 */
	public boolean addKey(String key, String helpText)
	{
		if(!key.equals(SEPARATOR) && key.length() > 0 && vKeys.indexOf(key) == -1)
		{
			vKeys.addElement(key);
			hmHelp.put(key, helpText);
			return true;
		}
		else
		{
			return false;
		}
	}
	
	/**
	 * Inserts a new key at the given position.
	 * @param key Name of the key
	 * @param pos Insert position
	 * @param helpText Help text of the key or <code>null</code> if not wanted.
	 * @return <code>true</code> if the key was inserted, <code>false</code> if the key is already known.
	 */
	public boolean insertKey(String key, int pos, String helpText)
	{
		if(!key.equals(SEPARATOR) && key.length() > 0 && vKeys.indexOf(key) == -1)
		{
			vKeys.insertElementAt(key, pos);
			hmHelp.put(key, helpText);
			return true;
		}
		else
		{
			return false;
		}
	}
	
	/**
	 * Get a list of all known keys.
	 * @return List of keys
	 */
	public Vector<String> getKeys()
	{
		Vector<String> retKeys = new Vector<String>();
		
		retKeys.addAll(vKeys);
		while (retKeys.removeElement(SEPARATOR));
		
		return retKeys;
	}
	
	/**
	 * Returns the value of the key.
	 * @param key Name of the key
	 * @return The value of the key or <code>null</code> if there is no value.
	 */
	public String getValue(String key)
	{
		return hmValue.get(key);
	}
	
	/**
	 * Returns the value of the key. If there is no value, the defValue will be returned.
	 * @param key Name of the key
	 * @param defValue Default value
	 * @return The value of the key or the default value if there is no value.
	 */
	public String getValue(String key, String defValue)
	{
		if (hmValue.get(key) == null)
		{
			return defValue;
		}
		else
		{
			return hmValue.get(key);
		}
	}
	
	/**
	 * Sets a value for the given key.
	 * @param key Name of the key
	 * @param value Value for the key
	 * @return <code>true</code> if the value was set, <code>false</code> if key not found.
	 */
	public boolean setValue(String key, String value)
	{
		if(!key.equals(SEPARATOR) && key.length() > 0 && vKeys.indexOf(key) != -1)
		{
			hmValue.put(key, value);
			return true;
		}
		else
		{
			return false;
		}
	}
	
	/**
	 * Sets a value for the given key.
	 * @param key Name of the key
	 * @param value Value for the key, will be converted to String.
	 * @return <code>true</code> if the value was set, <code>false</code> if key not found.
	 */
	public boolean setValue(String key, long value)
	{
		return setValue(key, Long.toString(value));
	}

	/**
	 * Sets a value for the given key.
	 * @param key Name of the key
	 * @param value Value for the key, will be converted to String.
	 * @return <code>true</code> if the value was set, <code>false</code> if key not found.
	 */
	public boolean setValue(String key, double value)
	{
		return setValue(key, Double.toString(value));
	}
	
	/**
	 * Sets a value for the given key.
	 * @param key Name of the key
	 * @param value Value for the key, will be converted to String.
	 * @return <code>true</code> if the value was set, <code>false</code> if key not found.
	 */
	public boolean setValue(String key, boolean value)
	{
		return setValue(key, Boolean.toString(value));
	}
	
	/**
	 * Clears all values.
	 */
	public void removeAllValues()
	{
		hmValue.clear();
	}
	
	/**
	 * Add a separator at the current position.
	 */
	public void addSeparator()
	{
		vKeys.addElement(SEPARATOR);
	}
	
	/**
	 * Insert separator at a given position.
	 * @param pos Position to insert separator.
	 */
	public void insertSeparator(int pos)
	{
		vKeys.insertElementAt(SEPARATOR, pos);
	}
	
	/**
	 * Removes all separators.
	 */
	public void removeAllSeparators()
	{
		while (vKeys.removeElement(SEPARATOR));
	}
	
	/**
	 * Returns number of stored keys.
	 * @return Key count
	 */
	public int getKeyCount()
	{
		return vKeys.size();
	}
	
	/**
	 * Get the help text of a key.
	 * @param key Name of the key
	 * @return The help text as String or <code>null</code> if the key has no help text.
	 */
	public String getHelpText(String key)
	{
		return hmHelp.get(key);
	}
	
	/**
	 * Remove a key. The help text and value of the key will be also removed.
	 * @param key Name of the key
	 * @return <code>true</code> if the key was removed, <code>false</code> if key not found.
	 */
	public boolean removeKey(String key)
	{
		if(!key.equals(SEPARATOR) && key.length() > 0 && vKeys.indexOf(key) != -1)
		{
			vKeys.removeElement(key);
			hmHelp.remove(key);
			hmValue.remove(key);
			return true;
		}
		else
		{
			return false;
		}
	}
	
	/**
	 * Load values from property file. Only the values of known keys will be read from file.
	 * @param filename File object of the property file.
	 * @return <code>true</code> if file was successfully read, <code>false</code> if not.
	 */
	public boolean loadValues(File file)
	{
		if (file == null || !file.isFile())
		{
			return false;
		}
		
		Properties prop = new Properties();
		
		try
		{
			prop.load(new FileInputStream(file));
			String temp;
			
			for (String key : vKeys)
			{
				temp = prop.getProperty(key);
				if (temp != null)
				{
					hmValue.put(key, temp);
				}
			}
		}
		catch (Exception e)
		{
			prop = null;
			return false;
		}
		
		prop = null;
		return true;
	}
	
	/**
	 * Load values from property file. Only the values of known keys will be read from file.
	 * @param filename Path to the property file.
	 * @return <code>true</code> if file was successfully read, <code>false</code> if not.
	 */
	public boolean loadValues(String filename)
	{
		if (filename == null)
		{
			return false;
		}
		
		return loadValues(new File(filename));
	}
	
	/**
	 * Write arranged property file to disk.
	 * @param filename Path where the file should be saved.
	 * @param header The header of the file or <code>null</code> if not wanted.
	 * @return <code>true</code> if file was successfully written, <code>false</code> if not.
	 */
	public boolean save(String filename, String header)
	{
		if (filename == null)
		{
			return false;
		}
		
		PrintStream ps;
		try
		{
			ps = new PrintStream(filename, "ISO-8859-1");
		}
		catch (Exception e)
		{
			return false;
		}
		
		if (header != null && header.length() > 0)
		{
			ps.println(convertString(header));
		}
		
		ps.println("# File created at " + sdf.format(new Date(System.currentTimeMillis())));
		ps.println();
		
		for (String key : vKeys)
		{
			if (key.equals(SEPARATOR))
			{
				ps.println();
				continue;
			}
			
			if (hmHelp.get(key) != null)
			{
				ps.println(convertString(hmHelp.get(key)));
			}
			
			if (hmValue.get(key) == null)
			{
				ps.print("#");
				ps.println(key);
			}
			else
			{
				ps.print(key);
				ps.print(" = ");
				ps.println(hmValue.get(key));
			}
		}
		
		ps.close();
		
		return true;
	}
	
	private String convertString(String text)
	{
		String retValue = "# " + text;
		
		retValue = retValue.replace("\\", "$[mkbackslashsave]");
		retValue = retValue.replace("\n", LINE_SEPARATOR + "# ");
		retValue = retValue.replace("$[mkbackslashsave]", "\\");
		
		return retValue;
	}
}
